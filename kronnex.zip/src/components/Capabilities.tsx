import React, { useState } from "react";
import { CAPABILITIES } from "../data";
import { motion } from "motion/react";
import { Check, HelpCircle, Laptop, Film, Users, Brain, Newspaper, BarChart } from "lucide-react";

export default function Capabilities() {
  const [hoveredIndex, setHoveredIndex] = useState<string | null>(null);

  const getIcon = (id: string) => {
    const cls = "w-6 h-6 text-neutral-800 group-hover:scale-110 transition-transform duration-300";
    switch (id) {
      case "perf":
        return <BarChart className={cls} />;
      case "creat":
        return <Laptop className={cls} />;
      case "video":
        return <Film className={cls} />;
      case "influ":
        return <Users className={cls} />;
      case "ai":
        return <Brain className={cls} />;
      case "print":
        return <Newspaper className={cls} />;
      default:
        return <HelpCircle className={cls} />;
    }
  };

  return (
    <section id="capabilities" className="py-24 bg-neutral-50 border-b border-neutral-100">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Title container */}
        <div className="max-w-xl mb-16">
          <span className="font-mono text-xs uppercase tracking-[0.2em] text-neutral-400 block mb-2">
            Our Ecosystem &amp; Suite
          </span>
          <h2 className="font-display font-medium text-3xl sm:text-5xl tracking-tight text-neutral-900">
            One studio. Full stack.
          </h2>
          <p className="text-sm md:text-base text-neutral-500 mt-4 font-light leading-relaxed">
            We handle creative concept, campaign management, optimization, and AI tooling under a single roof of accountability. Nothing gets distorted between design briefing and final lead reporting.
          </p>
        </div>

        {/* 3x2 Grid layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CAPABILITIES.map((cap) => (
            <div
              key={cap.id}
              onMouseEnter={() => setHoveredIndex(cap.id)}
              onMouseLeave={() => setHoveredIndex(null)}
              className="relative p-8 rounded-2xl bg-white border border-neutral-200 shadow-sm flex flex-col justify-between group transition-all duration-300 hover:border-black hover:shadow-md cursor-pointer min-h-[290px]"
            >
              <div>
                <div className="flex items-start justify-between mb-8">
                  <div className="p-3 bg-neutral-50 rounded-xl group-hover:bg-black group-hover:text-white transition-colors duration-300">
                    {getIcon(cap.id)}
                  </div>
                  <span className="font-mono text-sm text-neutral-300 font-bold group-hover:text-neutral-500 transition-colors">
                    {cap.index}
                  </span>
                </div>

                <h3 className="font-display font-medium text-lg text-neutral-900 group-hover:translate-x-0.5 transition-transform">
                  {cap.title}
                </h3>
                <p className="text-xs text-neutral-500 mt-3 leading-relaxed font-light font-sans">
                  {cap.description}
                </p>
                {cap.id === "print" && (
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      alert("Opening secure-print arm portal for Image Security Printers. Connection established.");
                    }}
                    className="inline-flex items-center gap-1.5 mt-4 text-[10px] font-semibold text-neutral-800 hover:text-black border border-neutral-200 hover:border-black rounded-full px-3 py-1 bg-white hover:bg-neutral-50 transition-all font-mono"
                  >
                    About Image Security Printers →
                  </button>
                )}
              </div>

              {/* Card Footer badges */}
              <div className="mt-8 pt-4 border-t border-neutral-100 flex items-center justify-between">
                {cap.tag ? (
                  <span className="bg-neutral-950 text-white font-mono text-[9px] uppercase tracking-wider px-2 py-0.5 rounded-full font-bold">
                    {cap.tag}
                  </span>
                ) : (
                  <span className="text-[10px] text-neutral-400 font-mono flex items-center gap-1 group-hover:text-neutral-900 transition-colors">
                    <Check className="w-3.5 h-3.5 text-emerald-500" /> Playbook Standardizado
                  </span>
                )}
                
                <span className="font-mono text-[10px] text-neutral-300 group-hover:text-neutral-600 transition-colors">
                  KRONNEX &bull; MODULE_0{cap.index}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
