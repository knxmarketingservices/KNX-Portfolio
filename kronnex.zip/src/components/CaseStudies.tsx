import React, { useState } from "react";
import { KRONNEX_WORK, FOUNDER_RECORD } from "../data";
import { CaseStudy } from "../types";
import { motion, AnimatePresence } from "motion/react";
import { MapPin, ArrowUpRight, TrendingUp, Sparkles, Image, CheckCircle, BarChart3 } from "lucide-react";

function TiltCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const [coords, setCoords] = useState({ x: 0, y: 0 });
  const [isHover, setIsHover] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setCoords({ x, y });
  };

  return (
    <div
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHover(true)}
      onMouseLeave={() => {
        setIsHover(false);
        setCoords({ x: 0, y: 0 });
      }}
      className={`transition-all duration-300 ease-out select-none cursor-pointer ${className}`}
      style={{
        transform: isHover
          ? `perspective(800px) rotateY(${coords.x * 12}deg) rotateX(${-coords.y * 12}deg) scale3d(1.015, 1.015, 1.015)`
          : "perspective(800px) rotateY(0deg) rotateX(0deg) scale3d(1, 1, 1)",
        transformStyle: "preserve-3d"
      }}
    >
      <div style={{ transform: isHover ? "translateZ(20px)" : "none", transition: "transform 0.3s" }}>
        {children}
      </div>
    </div>
  );
}

export default function CaseStudies() {
  const allCases = [...KRONNEX_WORK, ...FOUNDER_RECORD];

  return (
    <section id="work" className="py-24 bg-white border-b border-neutral-100">
      <div className="max-w-5xl mx-auto px-6">
        {/* Header */}
        <div className="mb-20 text-center max-w-2xl mx-auto">
          <span className="font-mono text-xs uppercase tracking-[0.2em] text-neutral-400 block mb-3">
            Our Portfolios &amp; Case Studies
          </span>
          <h2 className="font-display font-medium text-4xl sm:text-5xl tracking-tight text-neutral-900 leading-tight">
            Results, not deliverables.
          </h2>
          <p className="text-base text-neutral-500 mt-4 font-light">
            We gauge every customer partnership in calls, leads, and conversion metrics — not placeholder content calendars or vanity metrics. Below is the full ledger of selected engagements and the founder's historic background tracking.
          </p>
        </div>

        {/* Founder Resume Section at Top */}
        <div className="mb-24">
          <TiltCard className="bg-gradient-to-br from-neutral-900 via-neutral-950 to-indigo-950 text-white rounded-3xl border border-indigo-500/20 p-8 sm:p-10 shadow-2xl relative overflow-hidden">
            {/* Embedded vibrant glowing spots for Enhancing visual design */}
            <div className="absolute -top-20 -right-20 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-20 -left-20 w-48 h-48 bg-purple-500/20 rounded-full blur-2xl pointer-events-none" />
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
              <span className="font-mono text-[10px] sm:text-xs uppercase tracking-[0.2em] text-indigo-400 bg-indigo-950/50 px-3 py-1 rounded-md border border-indigo-500/10 inline-block w-max">
                EXECUTIVE PROFILE
              </span>
              <a
                href="https://www.linkedin.com/in/krishanthhariveerappan/"
                target="_blank"
                rel="noreferrer"
                className="text-xs font-mono text-neutral-400 hover:text-indigo-400 flex items-center gap-1.5 transition-colors group/ln bg-neutral-900/50 px-3 py-1.5 rounded-lg border border-neutral-800"
              >
                LinkedIn Connected <ArrowUpRight className="w-3.5 h-3.5 group-hover/ln:translate-x-0.5 transition-transform" />
              </a>
            </div>

            <div className="space-y-6 relative z-10">
              <div>
                <h3 className="font-display font-medium text-2xl sm:text-3xl leading-tight text-white mb-2">
                  Krishanth Hari Veerappan
                </h3>
                <p className="text-xs sm:text-sm font-mono text-neutral-300">
                  Founder, Kronnex &bull; Ads, Content &amp; AI Systems for Client Acquisition and Growth.
                </p>
                <p className="flex items-center gap-1.5 text-xs font-mono text-neutral-400 mt-2">
                  <MapPin className="w-3.5 h-3.5 text-neutral-500" /> Chennai, Tamil Nadu, India
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-indigo-500/20">
                <div className="space-y-4">
                  <p className="text-sm text-neutral-300 font-light leading-relaxed italic border-l-2 border-indigo-500 pl-4">
                    "I build simple systems that help businesses grow. Most businesses today are doing everything separately [ads, content, lead handling] but nothing actually works when secluding one from another. At Kronnex, we focus on connecting the dots."
                  </p>
                  <div className="flex flex-wrap gap-2 pt-2">
                    <span className="px-3 py-1 bg-neutral-800/80 border border-neutral-700/50 text-white text-xs font-mono rounded-md shadow-sm">
                      Facebook Ads
                    </span>
                    <span className="px-3 py-1 bg-neutral-800/80 border border-neutral-700/50 text-white text-xs font-mono rounded-md shadow-sm">
                      Lead Generation
                    </span>
                    <span className="px-3 py-1 bg-neutral-800/80 border border-neutral-700/50 text-white text-xs font-mono rounded-md shadow-sm">
                      Social Media Content Creation
                    </span>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-indigo-300 block mb-3">
                      Career Trajectory
                    </span>
                    <div className="space-y-3 text-xs text-neutral-300 font-light">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-white font-medium text-sm">Founder @ Kronnex Digital Solutions</span>
                        <span className="text-neutral-500 font-mono">May 2024 - Present &middot; Chennai</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-white font-medium text-sm">Digital Marketing Manager @ Image Innovation Tech</span>
                        <span className="text-neutral-500 font-mono">June 2024 - April 2025</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-white font-medium text-sm">Digital Marketing Intern @ SRM IST</span>
                        <span className="text-neutral-500 font-mono">Oct 2024 - Dec 2024</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-indigo-300 block mb-2">
                      Education
                    </span>
                    <p className="text-xs text-neutral-300 leading-normal">
                      <span className="font-medium text-white">SRMIST, Kattankulathur</span> &middot; BBA Digital Marketing (2023 - 2026)
                    </p>
                  </div>
                </div>
              </div>

            </div>
          </TiltCard>
        </div>

        {/* The List of Case Studies */}
        <div className="space-y-20 sm:space-y-32">
          {allCases.map((cs, idx) => (
            <div key={cs.id} className="relative">
              {/* Decorative side line for structure */}
              <div className="absolute left-0 top-0 bottom-0 w-[1px] bg-neutral-100 hidden sm:block -ml-8" />
              
              <div className="flex flex-col md:flex-row gap-4 md:items-end justify-between mb-8">
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-xs font-mono uppercase tracking-wider text-neutral-500 bg-neutral-100 px-2 py-0.5 rounded">
                      {cs.category}
                    </span>
                    <span className="flex items-center gap-1 text-xs font-mono text-neutral-400">
                      <MapPin className="w-3.5 h-3.5" /> {cs.location}
                    </span>
                  </div>
                  <h3 className="font-display font-medium text-3xl sm:text-4xl text-neutral-900 leading-tight">
                    {cs.clientName}
                  </h3>
                  <p className="text-lg text-neutral-600 font-light mt-2 max-w-2xl">
                    {cs.title}
                  </p>
                </div>
              </div>

              {/* Strategy Text */}
              <div className="mb-10 text-neutral-600 font-light leading-relaxed max-w-3xl">
                <p>{cs.description}</p>
              </div>

              {/* Stats Bar */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
                {cs.stats.map((stat, i) => (
                  <div key={i} className="pl-6 border-l-2 border-neutral-200 py-1">
                    <div className="font-display font-bold text-3xl text-neutral-900">{stat.value}</div>
                    <div className="text-[11px] font-mono uppercase tracking-wider text-neutral-500 mt-1">{stat.label}</div>
                  </div>
                ))}
              </div>

              {/* Work Assets (Images) */}
              <div className="mt-8">
                <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-400 block mb-4 flex items-center gap-2">
                  <Image className="w-3.5 h-3.5" /> Campaign Assets &amp; Visuals
                </span>
                
                {cs.id === "image-innovation" ? (
                  /* Custom Browser Mockup for Web Design Project */
                  <div className="border border-neutral-200 rounded-xl overflow-hidden shadow-xl shadow-black/5 bg-white">
                    <div className="bg-neutral-100 border-b border-neutral-200 px-4 py-3 flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full bg-neutral-300" />
                      <span className="w-3 h-3 rounded-full bg-neutral-300" />
                      <span className="w-3 h-3 rounded-full bg-neutral-300" />
                      <div className="ml-4 flex-1 bg-white border border-neutral-200 rounded px-3 py-1 flex items-center justify-center font-mono text-[10px] text-neutral-400 max-w-md mx-auto">
                        image-innovation.com
                      </div>
                    </div>
                    <div className="aspect-video bg-neutral-50 relative flex items-center justify-center overflow-hidden w-full">
                       <iframe src="https://iitpl.ai/" className="absolute inset-0 w-full h-full border-0" title="Image Innovation Technology Site" />
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {cs.captions.map((caption, i) => (
                      <div key={i} className="group relative aspect-[4/5] bg-neutral-100 rounded-2xl overflow-hidden border border-neutral-200">
                        {/* Placeholder for real images. We build an intense mockup feel. */}
                        <div className="absolute inset-0 bg-neutral-900 p-6 flex flex-col justify-between">
                          <div className="absolute inset-0 opacity-20"
                               style={{
                                 backgroundImage: "linear-gradient(to right, #404040 1px, transparent 1px), linear-gradient(to bottom, #404040 1px, transparent 1px)",
                                 backgroundSize: "24px 24px"
                               }}
                          />
                          <div className="relative z-10 flex justify-between">
                            <span className="font-mono text-[10px] text-neutral-400 bg-black/50 px-2 py-1 rounded">
                              FRAME 0{i + 1}
                            </span>
                            <span className="font-mono text-[10px] text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> LIVE
                            </span>
                          </div>
                          
                          <div className="relative z-10 w-full text-center">
                            <div className="w-16 h-16 sm:w-20 sm:h-20 border border-neutral-700 rounded-full flex items-center justify-center font-mono text-sm text-neutral-500 mx-auto mb-4 bg-neutral-950/80 backdrop-blur-sm group-hover:bg-neutral-800 group-hover:text-neutral-300 transition-all duration-300">
                              IMG_0{i+1}
                            </div>
                          </div>

                          <div className="relative z-10">
                            <p className="font-medium text-white text-sm">
                              {caption}
                            </p>
                            <p className="text-[10px] font-mono text-neutral-500 mt-1">
                              Creative Asset / Ad Module
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {cs.id === "srm" && (
                  <div className="mt-8 border border-neutral-200 rounded-xl bg-neutral-50 p-6 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-sm">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 bg-neutral-900 text-white rounded-xl flex items-center justify-center font-mono text-sm font-bold shadow-md">
                        PDF
                      </div>
                      <div>
                        <h5 className="font-semibold text-neutral-900 text-sm">srm-admissions-revamp.pdf</h5>
                        <p className="text-xs text-neutral-500 mt-1 font-light">Detailed conversion mappings and high-fidelity wireframes from the internship sprint.</p>
                      </div>
                    </div>
                    <button onClick={() => alert('Simulated document download.')} className="bg-white border border-neutral-300 hover:border-black text-xs font-semibold px-6 py-3 rounded-full text-neutral-900 transition-all w-full sm:w-auto shadow-sm tracking-wide">
                      Download PDF Document
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
